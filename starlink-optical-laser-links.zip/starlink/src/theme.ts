// theme.ts — সব রং, ইজিং, spring প্রিসেট ও ফন্ট এখানে। কম্পোনেন্টে সরাসরি রঙের কোড নয়।
// কালার স্কিম: "Deep Space" (ইউজারের নির্বাচন: ১)
import { Easing } from "remotion";
import { FONT_STACK } from "./fonts";

const colors = {
  bg: "#060B1A",
  bgAlt: "#0B1430",
  panel: "#0E1A3D",
  panelHi: "#16275C",
  primary: "#4DA3FF", // হিরো
  accent: "#7CF2E0",
  text: "#EAF2FF",
  textDim: "#8FA6C8",
  line: "rgba(143,166,200,0.32)",
  lineSoft: "rgba(143,166,200,0.14)",
  glow: "rgba(77,163,255,0.55)",
  glowAccent: "rgba(124,242,224,0.45)",
  glass: "rgba(14,26,61,0.62)",
  sheen: "rgba(255,255,255,0.06)",
  shade: "rgba(0,0,0,0.38)",
} as const;

export const theme = {
  colors,
  fonts: { display: FONT_STACK, body: FONT_STACK },
  type: { hero: 170, h1: 124, h2: 92, h3: 68, body: 44, label: 34, small: 28 },
  radius: { card: 36, small: 20, chip: 999 },
  shadow: {
    card: "0 40px 80px -24px rgba(0,0,0,0.65)",
    heroGlow: `0 0 60px ${colors.glow}`,
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1), // entrances
    inOut: Easing.bezier(0.83, 0, 0.17, 1), // moves
    in: Easing.bezier(0.7, 0, 0.84, 0), // exits
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
} as const;
