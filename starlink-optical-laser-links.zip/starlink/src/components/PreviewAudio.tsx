import React, { useEffect, useState } from "react";
import {
  Audio,
  continueRender,
  delayRender,
  getRemotionEnvironment,
  staticFile,
} from "remotion";
import { VOICEOVER_FILE, VOICEOVER_IN_PREVIEW, VOICEOVER_IN_RENDER } from "../config";

/** public/voiceover.mp3 থাকলে বাজে, না থাকলে নীরবে বাদ। */
export const PreviewAudio: React.FC = () => {
  const enabled = getRemotionEnvironment().isRendering
    ? VOICEOVER_IN_RENDER
    : VOICEOVER_IN_PREVIEW;
  const [exists, setExists] = useState(false);
  const [handle] = useState<number | null>(() =>
    enabled ? delayRender("voiceover check", { timeoutInMilliseconds: 15000 }) : null,
  );

  useEffect(() => {
    if (!enabled) return;
    let alive = true;
    fetch(staticFile(VOICEOVER_FILE), { method: "HEAD" })
      .then((r) => {
        const type = r.headers.get("content-type") ?? "";
        if (alive) setExists(r.ok && !type.includes("text/html"));
      })
      .catch(() => undefined)
      .finally(() => {
        if (handle !== null) continueRender(handle);
      });
    return () => {
      alive = false;
    };
  }, [enabled, handle]);

  if (!enabled || !exists) return null;
  return <Audio src={staticFile(VOICEOVER_FILE)} volume={1} />;
};
