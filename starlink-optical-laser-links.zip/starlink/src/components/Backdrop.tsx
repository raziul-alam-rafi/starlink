import React from "react";
import { AbsoluteFill, random, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { mix, ramp } from "./anim";
import { HEIGHT, WIDTH } from "../timing";

const STARS = Array.from({ length: 90 }, (_, i) => ({
  x: random(`sx${i}`) * (WIDTH + 200) - 100,
  y: random(`sy${i}`) * (HEIGHT + 80) - 40,
  r: 0.8 + random(`sr${i}`) * 1.8,
  ph: random(`sp${i}`) * 6.28,
  depth: 0.3 + random(`sd${i}`) * 0.7,
}));

/** স্তর ১: ব্যাকগ্রাউন্ড মেশ + তারা। কখনো ফ্ল্যাট নয়। */
export const Backdrop: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55) * 50;
  const d2 = Math.cos(frame / 70) * 40;
  return (
    <AbsoluteFill style={{ background: theme.colors.bg }}>
      <div
        style={{
          position: "absolute",
          width: 1300,
          height: 1300,
          borderRadius: "50%",
          top: -560,
          left: -360 + d1,
          filter: "blur(50px)",
          background: `radial-gradient(circle, ${theme.colors.panelHi}, transparent 62%)`,
          opacity: 0.8,
        }}
      />
      <div
        style={{
          position: "absolute",
          width: 1000,
          height: 1000,
          borderRadius: "50%",
          bottom: -520,
          right: -260 - d2,
          filter: "blur(70px)",
          background: `radial-gradient(circle, ${theme.colors.glow}, transparent 65%)`,
          opacity: 0.35,
        }}
      />
      <svg width={WIDTH} height={HEIGHT} style={{ position: "absolute", inset: 0 }}>
        {STARS.map((s, i) => {
          const tw = 0.5 + 0.5 * Math.sin(frame / 38 + s.ph);
          return (
            <circle
              key={i}
              cx={s.x - frame * 0.07 * s.depth}
              cy={s.y}
              r={s.r}
              fill={theme.colors.text}
              opacity={(0.18 + 0.5 * tw) * s.depth}
            />
          );
        })}
      </svg>
    </AbsoluteFill>
  );
};

/** স্তর ৪: কালার গ্রেড */
export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill
      style={{
        backgroundColor: theme.colors.primary,
        mixBlendMode: "soft-light",
        opacity: 0.18,
      }}
    />
    <AbsoluteFill
      style={{
        background:
          "linear-gradient(180deg, rgba(0,0,0,0.10), transparent 28%, transparent 72%, rgba(0,0,0,0.2))",
      }}
    />
  </AbsoluteFill>
);

/** স্তর ৫ক: গ্রেইন */
export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill
      style={{
        pointerEvents: "none",
        backgroundImage: noise,
        backgroundSize: "220px",
        backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`,
        opacity: 0.06,
        mixBlendMode: "overlay",
      }}
    />
  );
};

/** স্তর ৫খ: ভিনিয়েট */
export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      pointerEvents: "none",
      background: "radial-gradient(ellipse at center, transparent 56%, rgba(0,0,0,0.3) 100%)",
    }}
  />
);

/** সিন ট্রানজিশনের আলোর রেখা */
export const Sweep: React.FC<{ at: number }> = ({ at }) => {
  const frame = useCurrentFrame();
  if (frame < at || frame > at + 18) return null;
  const p = ramp(frame, at, 16, theme.ease.inOut);
  return (
    <AbsoluteFill style={{ pointerEvents: "none", overflow: "hidden" }}>
      <div
        style={{
          position: "absolute",
          top: -250,
          left: mix(-700, 2400, p),
          width: 340,
          height: 1600,
          transform: "rotate(16deg)",
          background: `linear-gradient(90deg, transparent, ${theme.colors.glowAccent}, ${theme.colors.glow}, transparent)`,
          filter: "blur(28px)",
          opacity: 0.6 * Math.sin(Math.PI * p),
        }}
      />
    </AbsoluteFill>
  );
};
