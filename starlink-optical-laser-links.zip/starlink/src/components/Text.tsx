import React from "react";
import { spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { useSpr } from "./anim";

export const gradText: React.CSSProperties = {
  backgroundImage: `linear-gradient(90deg, ${theme.colors.primary}, ${theme.colors.accent})`,
  WebkitBackgroundClip: "text",
  backgroundClip: "text",
  WebkitTextFillColor: "transparent",
  color: "transparent",
  padding: "0.15em 0.05em",
  margin: "-0.15em -0.05em",
};

/** শব্দ-বিভাজন শুধু স্পেসে (বাংলা অক্ষর কখনো ভাঙে না)। শব্দের আগে `*` = গ্রেডিয়েন্ট কীওয়ার্ড। */
export const WordReveal: React.FC<{
  text: string;
  at: number;
  size: number;
  per?: number;
  weight?: number;
  color?: string;
  align?: "left" | "center" | "right";
  maxWidth?: number;
  lineHeight?: number;
  style?: React.CSSProperties;
}> = ({ text, at, size, per = 4, weight = 700, color = theme.colors.text, align = "center", maxWidth, lineHeight = 1.32, style }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const words = text.split(" ").filter(Boolean);
  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        justifyContent: align === "center" ? "center" : align === "right" ? "flex-end" : "flex-start",
        columnGap: Math.round(size * 0.26),
        rowGap: 0,
        maxWidth,
        fontFamily: theme.fonts.display,
        fontSize: size,
        fontWeight: weight,
        lineHeight,
        letterSpacing: 0,
        color,
        ...style,
      }}
    >
      {words.map((raw, i) => {
        const hl = raw.startsWith("*");
        const w = hl ? raw.slice(1) : raw;
        const start = at + i * per;
        const p = frame < start ? 0 : spring({ frame: frame - start, fps, config: theme.spring.snappy });
        return (
          <span
            key={i}
            style={{
              display: "inline-block",
              opacity: Math.min(1, p * 1.5),
              transform: `translateY(${(1 - p) * 34}px) scale(${0.94 + 0.06 * p})`,
              filter: p < 1 ? `blur(${(1 - p) * 6}px)` : undefined,
              ...(hl ? gradText : {}),
            }}
          >
            {w}
          </span>
        );
      })}
    </div>
  );
};

/** লাইন মাস্ক রিভিল */
export const LineMask: React.FC<{
  children: React.ReactNode;
  at: number;
  size: number;
  weight?: number;
  color?: string;
  style?: React.CSSProperties;
}> = ({ children, at, size, weight = 700, color = theme.colors.text, style }) => {
  const p = useSpr(at, theme.spring.smooth);
  return (
    <div style={{ overflow: "hidden", padding: "0.3em 0.1em", margin: "-0.3em -0.1em", ...style }}>
      <div
        style={{
          fontFamily: theme.fonts.display,
          fontSize: size,
          fontWeight: weight,
          lineHeight: 1.3,
          letterSpacing: 0,
          color,
          opacity: Math.min(1, p * 1.6),
          transform: `translateY(${(1 - p) * 110}%)`,
          whiteSpace: "nowrap",
        }}
      >
        {children}
      </div>
    </div>
  );
};

/** সেন্টার-অ্যাঙ্করড পজিশন (x,y = কেন্দ্র) */
export const Anchor: React.FC<{
  x: number;
  y: number;
  children: React.ReactNode;
  origin?: "center" | "topleft";
}> = ({ x, y, children, origin = "center" }) => (
  <div
    style={{
      position: "absolute",
      left: x,
      top: y,
      width: "max-content",
      transform: origin === "center" ? "translate(-50%, -50%)" : undefined,
    }}
  >
    {children}
  </div>
);

/** ছোট লেবেল চিপ (বাউন্স পপ) */
export const Chip: React.FC<{
  at: number;
  children: React.ReactNode;
  size?: number;
  tone?: "hero" | "accent" | "dim";
  dot?: boolean;
}> = ({ at, children, size = theme.type.label, tone = "dim", dot = true }) => {
  const p = useSpr(at, theme.spring.bouncy);
  const c = tone === "hero" ? theme.colors.primary : tone === "accent" ? theme.colors.accent : theme.colors.textDim;
  return (
    <div
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 14,
        padding: `${Math.round(size * 0.3)}px ${Math.round(size * 0.7)}px`,
        borderRadius: theme.radius.chip,
        background: theme.colors.glass,
        border: `1.5px solid ${tone === "dim" ? theme.colors.line : c}`,
        fontFamily: theme.fonts.display,
        fontSize: size,
        fontWeight: 600,
        lineHeight: 1.3,
        letterSpacing: 0,
        color: theme.colors.text,
        whiteSpace: "nowrap",
        opacity: Math.min(1, p * 1.5),
        transform: `translateY(${(1 - p) * 18}px) scale(${0.85 + 0.15 * p})`,
      }}
    >
      {dot ? (
        <span style={{ width: size * 0.34, height: size * 0.34, borderRadius: "50%", background: c, display: "inline-block" }} />
      ) : null}
      {children}
    </div>
  );
};

/** গ্লাস কার্ড */
export const GlassCard: React.FC<{
  at: number;
  x: number;
  y: number;
  w: number;
  h: number;
  children?: React.ReactNode;
  tone?: "hero" | "dim";
  fade?: number;
  style?: React.CSSProperties;
}> = ({ at, x, y, w, h, children, tone = "dim", fade = 1, style }) => {
  const p = useSpr(at, theme.spring.smooth);
  return (
    <div
      style={{
        position: "absolute",
        left: x,
        top: y,
        width: w,
        height: h,
        borderRadius: theme.radius.card,
        background: `linear-gradient(180deg, ${theme.colors.sheen}, transparent 40%), ${theme.colors.glass}`,
        border: `1.5px solid ${tone === "hero" ? theme.colors.primary : theme.colors.line}`,
        boxShadow: tone === "hero" ? `${theme.shadow.card}, ${theme.shadow.heroGlow}` : theme.shadow.card,
        backdropFilter: "blur(14px)",
        opacity: Math.min(1, p * 1.4) * fade,
        transform: `translateY(${(1 - p) * 44}px) scale(${0.95 + 0.05 * p})`,
        fontFamily: theme.fonts.display,
        color: theme.colors.text,
        ...style,
      }}
    >
      {children}
    </div>
  );
};
