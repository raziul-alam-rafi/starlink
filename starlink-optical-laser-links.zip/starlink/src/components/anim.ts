import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";

type SpringCfg = { damping: number; stiffness: number; mass: number };

/** at ফ্রেম থেকে শুরু হওয়া spring (০→১, ওভারশুট সম্ভব)। */
export const useSpr = (at: number, cfg: SpringCfg = theme.spring.smooth): number => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  if (frame < at) return 0;
  return spring({ frame: frame - at, fps, config: cfg });
};

/** easing সহ ০→১ রাম্প (সবসময় clamp)। */
export const ramp = (
  frame: number,
  from: number,
  dur: number,
  easing: (t: number) => number = theme.ease.out,
): number =>
  interpolate(frame, [from, from + dur], [0, 1], {
    easing,
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

export const mix = (a: number, b: number, p: number): number => a + (b - a) * p;
export const clamp01 = (v: number): number => Math.max(0, Math.min(1, v));
