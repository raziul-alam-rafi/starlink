import React from "react";
import { Audio, Sequence, staticFile } from "remotion";

// SFX সেট (৬টি): public/sfx/ — স্ক্রিপ্ট: scripts/make-sfx.mjs
export const SFX = {
  pop: { file: "pop.wav", frames: 9, vol: 0.3 },
  click: { file: "click.wav", frames: 6, vol: 0.3 },
  whoosh: { file: "whoosh.wav", frames: 18, vol: 0.27 },
  swipe: { file: "swipe.wav", frames: 22, vol: 0.28 },
  chime: { file: "chime.wav", frames: 16, vol: 0.26 },
  thud: { file: "thud.wav", frames: 12, vol: 0.24 },
} as const;

export const Sfx: React.FC<{
  name: keyof typeof SFX;
  at: number;
  vol?: number;
  rate?: number;
}> = ({ name, at, vol = 1, rate = 1 }) => {
  const s = SFX[name];
  return (
    <Sequence from={Math.max(0, Math.round(at))} durationInFrames={s.frames + 10} layout="none">
      <Audio src={staticFile(`sfx/${s.file}`)} volume={s.vol * vol} playbackRate={rate} />
    </Sequence>
  );
};
