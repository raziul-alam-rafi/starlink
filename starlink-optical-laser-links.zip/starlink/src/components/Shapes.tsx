import React from "react";
import { random, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { clamp01, mix } from "./anim";
import { WIDTH, HEIGHT } from "../timing";

export type Pt = [number, number];

export const Stage: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <svg
    width={WIDTH}
    height={HEIGHT}
    viewBox={`0 0 ${WIDTH} ${HEIGHT}`}
    style={{ position: "absolute", left: 0, top: 0, overflow: "visible" }}
  >
    {children}
  </svg>
);

/** পৃথিবীর বক্ররেখা — কেন্দ্র (960, cy), ব্যাসার্ধ R */
export const surfaceY = (cy: number, R: number, x: number): number =>
  cy - Math.sqrt(Math.max(0, R * R - (x - 960) * (x - 960)));

const CITY = Array.from({ length: 26 }, (_, i) => ({
  a: random(`ca${i}`) * Math.PI * 0.8 + Math.PI * 0.1,
  d: 0.02 + random(`cd${i}`) * 0.22,
  ph: random(`cp${i}`) * 6.28,
}));

export const Earth: React.FC<{ cy: number; R: number; rise?: number; o?: number }> = ({ cy, R, rise = 0, o = 1 }) => {
  const frame = useCurrentFrame();
  const breathe = 0.5 + 0.5 * Math.sin(frame / 45);
  return (
    <g opacity={o} transform={`translate(0 ${rise})`}>
      <defs>
        <radialGradient id="earthFill" cx="50%" cy="0%" r="75%">
          <stop offset="0" stopColor={theme.colors.panelHi} />
          <stop offset="0.5" stopColor={theme.colors.panel} />
          <stop offset="1" stopColor={theme.colors.bg} />
        </radialGradient>
      </defs>
      <circle cx={960} cy={cy} r={R} fill="url(#earthFill)" />
      <circle cx={960} cy={cy} r={R * 0.94} fill="none" stroke={theme.colors.lineSoft} strokeWidth={2} />
      <circle cx={960} cy={cy} r={R * 0.87} fill="none" stroke={theme.colors.lineSoft} strokeWidth={2} />
      {CITY.map((c, i) => {
        const ang = c.a;
        const rr = R * (1 - c.d);
        return (
          <circle
            key={i}
            cx={960 + Math.cos(ang) * rr * -1}
            cy={cy - Math.sin(ang) * rr}
            r={2.4}
            fill={theme.colors.accent}
            opacity={0.25 + 0.4 * (0.5 + 0.5 * Math.sin(frame / 30 + c.ph))}
          />
        );
      })}
      <circle
        cx={960}
        cy={cy}
        r={R}
        fill="none"
        stroke={theme.colors.accent}
        strokeWidth={3}
        opacity={0.35 + 0.2 * breathe}
        style={{ filter: `drop-shadow(0 0 22px ${theme.colors.glowAccent})` }}
      />
    </g>
  );
};

export const Satellite: React.FC<{
  x: number;
  y: number;
  s?: number;
  rot?: number;
  o?: number;
  glow?: number;
  phase?: number;
  float?: number;
}> = ({ x, y, s = 1, rot = 0, o = 1, glow = 0.4, phase = 0, float = 6 }) => {
  const frame = useCurrentFrame();
  const bob = Math.sin(frame / 28 + phase) * float;
  const panel = (px: number) => (
    <g transform={`translate(${px} 0)`}>
      <rect x={0} y={-24} width={104} height={48} rx={7} fill={theme.colors.panelHi} stroke={theme.colors.line} strokeWidth={2} />
      {[26, 52, 78].map((gx) => (
        <line key={gx} x1={gx} y1={-24} x2={gx} y2={24} stroke={theme.colors.line} strokeWidth={1.5} />
      ))}
      <line x1={0} y1={0} x2={104} y2={0} stroke={theme.colors.line} strokeWidth={1.5} />
    </g>
  );
  return (
    <g transform={`translate(${x} ${y + bob}) rotate(${rot}) scale(${s})`} opacity={o}>
      {panel(-166)}
      {panel(62)}
      <rect x={-62} y={-5} width={124} height={10} rx={5} fill={theme.colors.line} />
      <rect x={-38} y={-38} width={76} height={76} rx={16} fill={theme.colors.panel} stroke={theme.colors.textDim} strokeWidth={2.5} />
      <rect x={-24} y={-24} width={48} height={48} rx={10} fill={theme.colors.bgAlt} stroke={theme.colors.line} strokeWidth={1.5} />
      <circle
        r={10}
        fill={theme.colors.accent}
        opacity={0.5 + 0.5 * glow}
        style={{ filter: `drop-shadow(0 0 ${6 + 14 * glow}px ${theme.colors.glowAccent})` }}
      />
    </g>
  );
};

/** লেজার বিম: a থেকে b পর্যন্ত p অনুপাতে আঁকা। */
export const Beam: React.FC<{
  a: Pt;
  b: Pt;
  p: number;
  strong?: number;
  color?: string;
  width?: number;
  dashed?: boolean;
  o?: number;
}> = ({ a, b, p, strong = 1, color = theme.colors.primary, width = 5, dashed = false, o = 1 }) => {
  if (p <= 0) return null;
  const ex = mix(a[0], b[0], clamp01(p));
  const ey = mix(a[1], b[1], clamp01(p));
  return (
    <g opacity={o}>
      {!dashed ? (
        <line
          x1={a[0]}
          y1={a[1]}
          x2={ex}
          y2={ey}
          stroke={color}
          strokeWidth={width * 3.4}
          strokeLinecap="round"
          opacity={0.5 * strong}
          style={{ filter: "blur(7px)" }}
        />
      ) : null}
      <line
        x1={a[0]}
        y1={a[1]}
        x2={ex}
        y2={ey}
        stroke={color}
        strokeWidth={width}
        strokeLinecap="round"
        strokeDasharray={dashed ? "4 16" : undefined}
        opacity={dashed ? 0.8 : 0.45 + 0.55 * strong}
      />
    </g>
  );
};

export const lerpPt = (a: Pt, b: Pt, t: number): Pt => [mix(a[0], b[0], t), mix(a[1], b[1], t)];

export const Packet: React.FC<{ x: number; y: number; o?: number; label?: string; s?: number }> = ({
  x,
  y,
  o = 1,
  label = "Data",
  s = 1,
}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={o}>
    {label ? (
      <>
        <rect
          x={-48}
          y={-21}
          width={96}
          height={42}
          rx={21}
          fill={theme.colors.accent}
          style={{ filter: `drop-shadow(0 0 12px ${theme.colors.glowAccent})` }}
        />
        <text
          x={0}
          y={10}
          textAnchor="middle"
          fontSize={27}
          fontWeight={700}
          fill={theme.colors.bg}
          fontFamily={theme.fonts.display}
        >
          {label}
        </text>
      </>
    ) : (
      <circle r={9} fill={theme.colors.accent} style={{ filter: `drop-shadow(0 0 10px ${theme.colors.glowAccent})` }} />
    )}
  </g>
);

export const GroundStation: React.FC<{ x: number; y: number; s?: number; o?: number; glow?: number }> = ({
  x,
  y,
  s = 1,
  o = 1,
  glow = 0,
}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={o}>
    <path d="M-34 0 L-14 -52 L14 -52 L34 0 Z" fill={theme.colors.panelHi} stroke={theme.colors.line} strokeWidth={2.5} />
    <g transform="translate(0 -58) rotate(-28)">
      <path d="M-56 0 Q0 58 56 0 Z" fill={theme.colors.panel} stroke={theme.colors.text} strokeWidth={3} strokeLinejoin="round" />
      <line x1={0} y1={14} x2={0} y2={-40} stroke={theme.colors.text} strokeWidth={3.5} strokeLinecap="round" />
      <circle
        cx={0}
        cy={-46}
        r={7}
        fill={theme.colors.accent}
        style={{ filter: `drop-shadow(0 0 ${4 + 14 * glow}px ${theme.colors.glowAccent})` }}
      />
    </g>
  </g>
);

export const UserDish: React.FC<{ x: number; y: number; s?: number; o?: number }> = ({ x, y, s = 1, o = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={o}>
    <line x1={0} y1={0} x2={0} y2={-52} stroke={theme.colors.line} strokeWidth={9} strokeLinecap="round" />
    <path d="M-30 0 L30 0" stroke={theme.colors.line} strokeWidth={9} strokeLinecap="round" />
    <g transform="translate(0 -66) rotate(-20)">
      <ellipse rx={70} ry={24} fill={theme.colors.panelHi} stroke={theme.colors.text} strokeWidth={3} />
      <ellipse rx={42} ry={13} fill={theme.colors.panel} stroke={theme.colors.line} strokeWidth={2} />
    </g>
  </g>
);

export const GlobeIcon: React.FC<{ x: number; y: number; r?: number; o?: number; glow?: number }> = ({
  x,
  y,
  r = 56,
  o = 1,
  glow = 0,
}) => (
  <g transform={`translate(${x} ${y})`} opacity={o}>
    <circle
      r={r}
      fill={theme.colors.panel}
      stroke={theme.colors.primary}
      strokeWidth={3.5}
      style={{ filter: `drop-shadow(0 0 ${6 + 20 * glow}px ${theme.colors.glow})` }}
    />
    <ellipse rx={r * 0.42} ry={r} fill="none" stroke={theme.colors.line} strokeWidth={2.5} />
    <ellipse rx={r * 0.8} ry={r} fill="none" stroke={theme.colors.lineSoft} strokeWidth={2} />
    <line x1={-r} y1={0} x2={r} y2={0} stroke={theme.colors.line} strokeWidth={2.5} />
    <path d={`M${-r * 0.88} ${-r * 0.48} Q0 ${-r * 0.3} ${r * 0.88} ${-r * 0.48}`} fill="none" stroke={theme.colors.lineSoft} strokeWidth={2} />
    <path d={`M${-r * 0.88} ${r * 0.48} Q0 ${r * 0.3} ${r * 0.88} ${r * 0.48}`} fill="none" stroke={theme.colors.lineSoft} strokeWidth={2} />
  </g>
);

export const XMark: React.FC<{ x: number; y: number; p: number; r?: number }> = ({ x, y, p, r = 38 }) => {
  if (p <= 0) return null;
  const a = clamp01(p * 2);
  const b = clamp01(p * 2 - 1);
  const k = r * 0.42;
  const len = k * 2 * 1.4143;
  return (
    <g transform={`translate(${x} ${y}) scale(${0.7 + 0.3 * clamp01(p)})`} opacity={clamp01(p * 3)}>
      <circle r={r} fill={theme.colors.bgAlt} stroke={theme.colors.textDim} strokeWidth={3} />
      <line x1={-k} y1={-k} x2={k} y2={k} stroke={theme.colors.textDim} strokeWidth={8} strokeLinecap="round" strokeDasharray={len} strokeDashoffset={len * (1 - a)} />
      <line x1={k} y1={-k} x2={-k} y2={k} stroke={theme.colors.textDim} strokeWidth={8} strokeLinecap="round" strokeDasharray={len} strokeDashoffset={len * (1 - b)} />
    </g>
  );
};

export const CheckMark: React.FC<{ x: number; y: number; p: number; r?: number }> = ({ x, y, p, r = 38 }) => {
  if (p <= 0) return null;
  const k = r / 38;
  return (
    <g transform={`translate(${x} ${y}) scale(${(0.7 + 0.3 * clamp01(p)) * k})`} opacity={clamp01(p * 3)}>
      <circle r={38} fill={theme.colors.bgAlt} stroke={theme.colors.accent} strokeWidth={3.5} style={{ filter: `drop-shadow(0 0 14px ${theme.colors.glowAccent})` }} />
      <path
        d="M-17 2 L-5 15 L19 -13"
        fill="none"
        stroke={theme.colors.accent}
        strokeWidth={9}
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeDasharray={64}
        strokeDashoffset={64 * (1 - clamp01(p))}
      />
    </g>
  );
};
