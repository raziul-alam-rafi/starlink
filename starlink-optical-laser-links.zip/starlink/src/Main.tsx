import React from "react";
import { AbsoluteFill, Sequence, useCurrentFrame } from "remotion";
import { theme } from "./theme";
import { Backdrop, Grade, Grain, Sweep, Vignette } from "./components/Backdrop";
import { PreviewAudio } from "./components/PreviewAudio";
import { Sfx } from "./components/Sfx";
import { mix, ramp } from "./components/anim";
import { SCENES } from "./scenes";
import { sceneTimings, SceneTiming } from "./timing";

const SceneShell: React.FC<{ timing: SceneTiming; children: React.ReactNode }> = ({ timing, children }) => {
  const frame = useCurrentFrame();
  const enter = timing.isFirst ? 1 : ramp(frame, 0, 12);
  const exit = timing.isLast ? 0 : ramp(frame, timing.dur - 10, 9, theme.ease.in);
  return (
    <AbsoluteFill
      style={{
        opacity: enter * (1 - exit),
        transform: `translateY(${mix(24, 0, enter) - exit * 18}px) scale(${mix(0.985, 1, enter) + exit * 0.03})`,
        filter: enter < 1 ? `blur(${(1 - enter) * 6}px)` : undefined,
      }}
    >
      {children}
    </AbsoluteFill>
  );
};

export const Main: React.FC = () => (
  <AbsoluteFill style={{ background: theme.colors.bg }}>
    <Backdrop />
    {SCENES.map((Scene, i) => {
      const t = sceneTimings[i];
      return (
        <Sequence key={i} from={t.from} durationInFrames={t.dur}>
          <SceneShell timing={t}>
            <Scene t={t} />
          </SceneShell>
        </Sequence>
      );
    })}
    {sceneTimings.slice(1).map((t) => (
      <Sequence key={`tr${t.index}`} from={t.from} durationInFrames={24}>
        <Sweep at={0} />
        <Sfx name="swipe" at={0} />
      </Sequence>
    ))}
    <Grade />
    <Grain />
    <Vignette />
    <PreviewAudio />
  </AbsoluteFill>
);
