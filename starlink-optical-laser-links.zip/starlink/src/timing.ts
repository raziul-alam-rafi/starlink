// সময়ের একমাত্র উৎস: SRT। কোনো ফ্রেম নম্বর হাতে বসানো নেই।
import { SRT_RAW } from "./subtitles";

export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
export const LEAD = 5; // ভিজ্যুয়াল কথার ৪-৬ ফ্রেম আগে ঢোকে

export type Cue = {
  n: number;
  startMs: number;
  endMs: number;
  text: string;
  startF: number;
  endF: number;
  durF: number;
};

const toMs = (s: string): number => {
  const m = s.trim().match(/(\d+):(\d+):(\d+)[,.](\d+)/);
  if (!m) throw new Error(`Bad SRT time: ${s}`);
  return (+m[1] * 3600 + +m[2] * 60 + +m[3]) * 1000 + +m[4];
};

const parseSrt = (raw: string): Cue[] =>
  raw
    .replace(/\r\n/g, "\n")
    .trim()
    .split(/\n\s*\n/)
    .map((block) => {
      const lines = block.split("\n");
      const n = parseInt(lines[0], 10);
      const [a, b] = lines[1].split("-->");
      const startMs = toMs(a);
      const endMs = toMs(b);
      const startF = Math.round((startMs / 1000) * FPS);
      const endF = Math.round((endMs / 1000) * FPS);
      return {
        n,
        startMs,
        endMs,
        text: lines.slice(2).join(" "),
        startF,
        endF,
        durF: endF - startF,
      };
    });

export const cues: Cue[] = parseSrt(SRT_RAW);
export const cue = (n: number): Cue => {
  const c = cues.find((x) => x.n === n);
  if (!c) throw new Error(`No cue ${n}`);
  return c;
};

export const TOTAL_FRAMES = cues[cues.length - 1].endF;

// সিন = cue-র গ্রুপ (সিনের সীমা cue-র সীমায় মেলে)
export const SCENE_CUES: number[][] = [[1, 2], [3, 4], [5, 6], [7], [8, 9], [10]];

export type Timer = {
  from: number; // গ্লোবাল ফ্রেম
  dur: number;
  /** cue n-এর frac অংশে (০-১) কথা পৌঁছালে সিনের লোকাল ফ্রেম, LEAD আগে। */
  at: (n: number, frac?: number) => number;
  cueDur: (n: number) => number;
};

export type SceneTiming = Timer & { index: number; isFirst: boolean; isLast: boolean };

export const sceneTimings: SceneTiming[] = SCENE_CUES.map((group, index) => {
  const isFirst = index === 0;
  const isLast = index === SCENE_CUES.length - 1;
  const first = cue(group[0]);
  const from = isFirst ? 0 : first.startF - LEAD;
  const end = isLast ? TOTAL_FRAMES : cue(SCENE_CUES[index + 1][0]).startF;
  return {
    index,
    isFirst,
    isLast,
    from,
    dur: end - from,
    at: (n, frac = 0) => {
      const c = cue(n);
      return Math.max(0, Math.round(c.startF + frac * c.durF - LEAD - from));
    },
    cueDur: (n) => cue(n).durF,
  };
});
