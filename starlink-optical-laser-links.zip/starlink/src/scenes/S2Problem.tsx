import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { ramp, useSpr } from "../components/anim";
import { Anchor, Chip, GlassCard } from "../components/Text";
import {
  Beam,
  Earth,
  GroundStation,
  lerpPt,
  Packet,
  Pt,
  Satellite,
  Stage,
  surfaceY,
  UserDish,
  XMark,
} from "../components/Shapes";
import { Sfx } from "../components/Sfx";
import { SceneProps } from "./util";

// সিন ২ — সমস্যা (cue ৩-৪): Glass Cards + ত্রিভুজ লেআউট
const CY = 1700;
const R = 1000;
const DISH: Pt = [300, surfaceY(CY, R, 300)];
const GS: Pt = [1600, surfaceY(CY, R, 1600)];
const SA: Pt = [800, 360];
const SB: Pt = [1330, 260];
const DISH_TOP: Pt = [300, 850];
const GS_TOP: Pt = [1600, 850];

export const S2Problem: React.FC<SceneProps> = ({ t }) => {
  const frame = useCurrentFrame();
  const tCard = 8;
  const tA = t.at(3, 0.2);
  const tBeam1 = t.at(3, 0.26);
  const tGS = t.at(3, 0.62);
  const tDash = t.at(4, 0);
  const tX = t.at(4, 0.36);
  const tB = t.at(4, 0.58);
  const tHop = t.at(4, 0.78);

  const rise = (1 - ramp(frame, 0, 36)) * 90;
  const dishP = useSpr(4, theme.spring.bouncy);
  const aP = useSpr(tA, theme.spring.smooth);
  const gsP = useSpr(tGS, theme.spring.bouncy);
  const bP = useSpr(tB, theme.spring.smooth);
  const xP = useSpr(tX, theme.spring.bouncy);

  const beam1 = ramp(frame, tBeam1, 26);
  const dash = ramp(frame, tDash, 24);
  const beamAB = ramp(frame, tB + 4, 22);

  // প্যাকেট: ডিশ → A (বসে থাকে) → B
  const toA = ramp(frame, tBeam1 + 16, 34, theme.ease.inOut);
  const hop = ramp(frame, tHop, 26, theme.ease.inOut);
  const aPos: Pt = [SA[0], SA[1] - 84];
  const bPos: Pt = [SB[0], SB[1] - 76];
  let pk: Pt = lerpPt(DISH_TOP, aPos, toA);
  if (frame >= tHop) pk = lerpPt(aPos, bPos, hop);
  const pktO = ramp(frame, tBeam1 + 12, 6);
  const idle = Math.sin(frame / 14) * 4;

  return (
    <AbsoluteFill>
      <GlassCard at={tCard} x={90} y={540} w={340} h={96} style={{ display: "flex", alignItems: "center", justifyContent: "center", fontSize: 42, fontWeight: 600 }}>
        আপনার Data
      </GlassCard>

      <Stage>
        <Earth cy={CY} R={R} rise={rise} />
        <Beam a={DISH_TOP} b={SA} p={beam1} strong={0.9} width={5} />
        <Beam a={SA} b={GS_TOP} p={dash} dashed width={5} color={theme.colors.textDim} />
        <Beam a={SA} b={SB} p={beamAB} strong={1} width={6} />
        <UserDish x={DISH[0]} y={DISH[1] + (1 - dishP) * 40} s={1.2} o={Math.min(1, dishP * 1.5)} />
        <GroundStation x={GS[0]} y={GS[1] + (1 - gsP) * 40} s={1.15} o={Math.min(1, gsP * 1.5)} glow={0.2} />
        <Satellite x={SA[0]} y={SA[1] - (1 - aP) * 120} s={0.95} o={Math.min(1, aP * 1.5)} glow={0.5} />
        <Satellite x={SB[0]} y={SB[1] - (1 - bP) * 120} s={0.8} o={Math.min(1, bP * 1.5)} glow={0.9} phase={1.2} />
        <XMark x={1200} y={615} p={xP} r={34} />
        <Packet x={pk[0]} y={pk[1] + idle} o={pktO} />
      </Stage>

      <Anchor x={1600} y={1010}>
        <Chip at={tGS + 6} size={30}>Ground Station</Chip>
      </Anchor>
      <Anchor x={1460} y={612}>
        <Chip at={tX + 8} size={32}>সুবিধাজনক নয়</Chip>
      </Anchor>
      <Anchor x={1000} y={158}>
        <Chip at={tB + 10} size={32} tone="hero">নেটওয়ার্কের সংযোগ</Chip>
      </Anchor>

      <Sfx name="pop" at={tCard + 2} />
      <Sfx name="pop" at={tGS} rate={0.95} />
      <Sfx name="click" at={tX} />
      <Sfx name="pop" at={tB} rate={1.1} />
    </AbsoluteFill>
  );
};
