import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { Anchor, Chip, WordReveal } from "../components/Text";
import { Satellite, Stage } from "../components/Shapes";
import { ramp } from "../components/anim";
import { Sfx } from "../components/Sfx";
import { SceneProps } from "./util";

// সিন ৬ — সমাপ্তি / Statement Card (cue ১০)
const ring = (angle: number, rx: number, ry: number, rot: number): [number, number] => {
  const x = Math.cos(angle) * rx;
  const y = Math.sin(angle) * ry;
  const r = (rot * Math.PI) / 180;
  return [960 + x * Math.cos(r) - y * Math.sin(r), 540 + x * Math.sin(r) + y * Math.cos(r)];
};

export const S6End: React.FC<SceneProps> = ({ t }) => {
  const frame = useCurrentFrame();
  const tL1 = t.at(10, 0);
  const tL2 = t.at(10, 0.42);
  const tChip = t.at(10, 0.78);
  const rings = [
    { rx: 760, ry: 250, rot: -12, ph: 0.4, sp: 0.022 },
    { rx: 640, ry: 190, rot: 10, ph: 3.2, sp: -0.018 },
  ];
  const o = ramp(frame, 0, 20);
  return (
    <AbsoluteFill>
      <AbsoluteFill
        style={{
          background: `radial-gradient(ellipse 55% 38% at 50% 48%, ${theme.colors.glow}, transparent 70%)`,
          opacity: 0.22 * o,
        }}
      />
      <Stage>
        {rings.map((r, i) => (
          <g key={i} opacity={o}>
            <ellipse cx={960} cy={540} rx={r.rx} ry={r.ry} transform={`rotate(${r.rot} 960 540)`} fill="none" stroke={theme.colors.line} strokeWidth={3} strokeDasharray="2 12" strokeLinecap="round" opacity={0.9} />
            {(() => {
              const p = ring(r.ph + frame * r.sp, r.rx, r.ry, r.rot);
              // টেক্সটের ওপর দিয়ে গেলে ম্লান হয়ে যায় (টেক্সট ঢাকে না)
              const near = Math.abs(p[0] - 960) < 760 ? Math.max(0, Math.min(1, (Math.abs(p[1] - 540) - 170) / 70)) : 1;
              return <Satellite x={p[0]} y={p[1]} s={0.55} glow={0.7} float={0} phase={i} o={near} />;
            })()}
          </g>
        ))}
      </Stage>
      <Anchor x={960} y={470}>
        <WordReveal text="নেটওয়ার্কের *দক্ষতা" at={tL1} per={5} size={theme.type.h1} />
      </Anchor>
      <Anchor x={960} y={628}>
        <WordReveal text="আরও বাড়াতে সাহায্য করে" at={tL2} size={theme.type.h3 - 4} weight={500} color={theme.colors.textDim} />
      </Anchor>
      <Anchor x={960} y={900}>
        <Chip at={tChip} size={30} tone="accent">Starlink · Optical Laser Link</Chip>
      </Anchor>
      <Sfx name="chime" at={tL2} />
    </AbsoluteFill>
  );
};
