import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { ramp, useSpr } from "../components/anim";
import { WordReveal } from "../components/Text";
import { Beam, Earth, lerpPt, Packet, Pt, Satellite, Stage } from "../components/Shapes";
import { Sfx } from "../components/Sfx";
import { SceneProps } from "./util";

// সিন ৪ — আকাশে বিশাল Data Network (cue ৭): মেশ নেটওয়ার্ক
const NODES: Pt[] = [
  [1060, 320], [1260, 210], [1480, 280], [1700, 200], [1820, 420],
  [1160, 540], [1360, 450], [1570, 500], [1760, 640], [1240, 780],
  [1450, 690], [1650, 850], [1060, 820],
];
const EDGES: [number, number][] = [];
for (let i = 0; i < NODES.length; i++) {
  for (let j = i + 1; j < NODES.length; j++) {
    const d = Math.hypot(NODES[i][0] - NODES[j][0], NODES[i][1] - NODES[j][1]);
    if (d < 300) EDGES.push([i, j]);
  }
}
const PULSES: [number, number][] = [[0, 1], [1, 2], [2, 3], [6, 7], [7, 8], [9, 10], [10, 11], [5, 6]];

export const S4Network: React.FC<SceneProps> = ({ t }) => {
  const frame = useCurrentFrame();
  const tL1 = t.at(7, 0.16);
  const tL2 = t.at(7, 0.4);
  const tL3 = t.at(7, 0.56);
  const tMesh = t.at(7, 0.3);
  const tPulse = t.at(7, 0.7);
  const nodeAt = (i: number) => tMesh + i * 5;

  return (
    <AbsoluteFill>
      <Stage>
        <Earth cy={2250} R={1300} rise={(1 - ramp(frame, 0, 36)) * 90} o={0.9} />
        {EDGES.map(([a, b], k) => (
          <Beam
            key={k}
            a={NODES[a]}
            b={NODES[b]}
            p={ramp(frame, nodeAt(Math.max(a, b)) + 2, 14)}
            strong={0.25 + 0.2 * Math.sin(frame / 20 + k)}
            width={3.5}
          />
        ))}
        {NODES.map((n, i) => (
          <NodeSat key={i} n={n} i={i} at={nodeAt(i)} />
        ))}
        {PULSES.map(([a, b], k) => {
          if (frame < tPulse + k * 6) return null;
          const tt = (((frame - tPulse - k * 6) % 46) / 46);
          const pos = lerpPt(NODES[a], NODES[b], theme.ease.inOut(tt));
          return <Packet key={k} x={pos[0]} y={pos[1]} label="" o={ramp(frame, tPulse + k * 6, 8)} />;
        })}
      </Stage>
      <div style={{ position: "absolute", left: 110, top: 300 }}>
        <WordReveal text="আকাশের মধ্যে তৈরি" at={tL1} size={84} weight={500} align="left" color={theme.colors.textDim} />
        <WordReveal text="বিশাল" at={tL2} size={120} align="left" />
        <WordReveal text="*Data *Network" at={tL3} per={6} size={124} align="left" />
      </div>
      <Sfx name="pop" at={tL1 + 2} />
      <Sfx name="pop" at={tL3} rate={1.06} />
      <Sfx name="pop" at={tMesh + 4} rate={0.94} />
    </AbsoluteFill>
  );
};

const NodeSat: React.FC<{ n: Pt; i: number; at: number }> = ({ n, i, at }) => {
  const p = useSpr(at, theme.spring.bouncy);
  return <Satellite x={n[0]} y={n[1]} s={0.3 * (0.6 + 0.4 * Math.min(1.1, p))} o={Math.min(1, p * 1.6)} glow={0.5} phase={i * 0.7} float={4} />;
};
