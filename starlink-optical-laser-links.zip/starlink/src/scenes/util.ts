import { theme } from "../theme";
import type { Timer } from "../timing";

export type SceneProps = { t: Timer };

/** start থেকে period ফ্রেমের লুপ; আগে -1। ঢালু (eased) প্রগতি ০→১ */
export const loop = (frame: number, start: number, period: number): number => {
  if (frame < start) return -1;
  return theme.ease.inOut(((frame - start) % period) / period);
};
