import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { mix, ramp, useSpr } from "../components/anim";
import { Anchor, Chip, WordReveal } from "../components/Text";
import { Beam, Earth, Packet, Satellite, Stage, XMark } from "../components/Shapes";
import { Sfx } from "../components/Sfx";
import { SceneProps } from "./util";

// সিন ১ — হুক (cue ১-২): Kinetic Typography + লেজার-লিংক
const A: [number, number] = [400, 790];
const B: [number, number] = [1520, 790];
const BEAM_A: [number, number] = [612, 790];
const BEAM_B: [number, number] = [1308, 790];

export const S1Hook: React.FC<SceneProps> = ({ t }) => {
  const frame = useCurrentFrame();
  const tKick = t.at(1, 0.1);
  const tTitle = t.at(1, 0.72);
  const tSub = t.at(2, 0);
  const tDesc = t.at(2, 0.3);
  const tPkt = t.at(2, 0.62);

  const e1 = useSpr(0, theme.spring.smooth);
  const e2 = useSpr(6, theme.spring.smooth);
  const earthRise = (1 - ramp(frame, 0, 40)) * 120;
  const beamP = ramp(frame, 24, 26);
  const strong = 0.35 + 0.65 * ramp(frame, tTitle, 14) + Math.sin(frame / 9) * 0.06;
  const descP = ramp(frame, tDesc, 18);
  const xP = useSpr(tDesc + 14, theme.spring.bouncy);
  const pktIn = ramp(frame, tPkt, 8);

  const raw = frame < tPkt ? -1 : ((frame - tPkt) % 54) / 54;
  const e = raw < 0 ? 0 : theme.ease.inOut(raw);
  const edge = raw < 0 ? 0 : Math.min(1, raw * 9, (1 - raw) * 9);
  const lo = BEAM_A[0] + 70;
  const hi = BEAM_B[0] - 70;

  return (
    <AbsoluteFill>
      <Stage>
        <Earth cy={2460} R={1500} rise={earthRise} />
        <Beam a={BEAM_A} b={BEAM_B} p={beamP} strong={Math.min(1, strong)} width={6} />
        <Beam a={[960, 800]} b={[960, 950]} p={descP} dashed width={5} color={theme.colors.textDim} />
        <XMark x={960} y={876} p={xP} r={34} />
        <Satellite x={mix(-300, A[0], e1)} y={A[1]} s={1.15} rot={(1 - e1) * -10} o={Math.min(1, e1 * 1.5)} glow={strong} />
        <Satellite x={mix(2200, B[0], e2)} y={B[1]} s={1.15} rot={(1 - e2) * 10} o={Math.min(1, e2 * 1.5)} glow={strong} phase={1.6} />
        {raw >= 0 ? <Packet x={mix(lo, hi, e)} y={790} o={pktIn * edge} /> : null}
        {raw >= 0 ? <Packet x={mix(hi, lo, e)} y={790} label="" o={pktIn * edge} /> : null}
      </Stage>

      <Anchor x={960} y={100}>
        <Chip at={4} tone="accent">Starlink</Chip>
      </Anchor>
      <Anchor x={960} y={208}>
        <WordReveal text="আরেকটি চমৎকার প্রযুক্তি" at={tKick} size={theme.type.h3 - 8} weight={500} color={theme.colors.textDim} />
      </Anchor>
      <Anchor x={960} y={385}>
        <WordReveal text="Optical *Laser" at={tTitle} per={5} size={theme.type.hero} />
      </Anchor>
      <Anchor x={960} y={566}>
        <WordReveal text="যোগাযোগ" at={tSub} size={96} weight={600} />
      </Anchor>
      <Anchor x={1290} y={876}>
        <Chip at={tDesc + 10} size={32}>পৃথিবীতে না নেমেই</Chip>
      </Anchor>

      <Sfx name="whoosh" at={tTitle} />
      <Sfx name="thud" at={tTitle + 2} vol={0.8} />
      <Sfx name="pop" at={tDesc + 14} />
      <Sfx name="pop" at={tPkt} rate={1.08} />
    </AbsoluteFill>
  );
};
