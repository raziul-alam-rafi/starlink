import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { ramp, useSpr } from "../components/anim";
import { Anchor, Chip, WordReveal } from "../components/Text";
import { Beam, Earth, GlobeIcon, GroundStation, lerpPt, Packet, Pt, Satellite, Stage, surfaceY } from "../components/Shapes";
import { Sfx } from "../components/Sfx";
import { SceneProps } from "./util";

// সিন ৩ — Timeline / Process Flow (cue ৫-৬): স্যাটেলাইট থেকে স্যাটেলাইটে হপ
const CY = 1900;
const R = 1100;
const SATS: Pt[] = [
  [250, 560],
  [550, 420],
  [860, 360],
  [1170, 420],
];
const GS: Pt = [1440, surfaceY(CY, R, 1440)];
const GS_TOP: Pt = [1440, 790];
const GLOBE: Pt = [1660, 630];

export const S3Relay: React.FC<SceneProps> = ({ t }) => {
  const frame = useCurrentFrame();
  // cue ৫-এ চারটি স্যাটেলাইট সমান ব্যবধানে (০, .২২, .৪৪, .৬৬)
  const tSat = [0, 1, 2, 3].map((k) => t.at(5, k * 0.22));
  const tHead = t.at(5, 0.6);
  const tGS = t.at(6, 0.1);
  const tDown = t.at(6, 0.2);
  const tPktDown = t.at(6, 0.32);
  const tGlobe = t.at(6, 0.48);
  const tFiber = t.at(6, 0.54);
  const tPktFiber = t.at(6, 0.64);

  const s0 = useSpr(tSat[0], theme.spring.bouncy);
  const s1 = useSpr(tSat[1], theme.spring.bouncy);
  const s2 = useSpr(tSat[2], theme.spring.bouncy);
  const s3 = useSpr(tSat[3], theme.spring.bouncy);
  const sp = [s0, s1, s2, s3];
  const gsP = useSpr(tGS, theme.spring.bouncy);
  const globeP = useSpr(tGlobe, theme.spring.bouncy);

  const rise = (1 - ramp(frame, 0, 36)) * 90;

  // প্যাকেটের অবস্থান: P1 → P2 → P3 → P4 → GS → Globe
  const hopDur = 20;
  const stops: Pt[] = [SATS[0], SATS[1], SATS[2], SATS[3], GS_TOP, GLOBE];
  const starts = [tSat[1] + 8, tSat[2] + 8, tSat[3] + 8, tPktDown, tPktFiber];
  const durs = [hopDur, hopDur, hopDur, 22, 24];
  let pos: Pt = [SATS[0][0], SATS[0][1] - 78];
  let seg = -1;
  for (let i = 0; i < starts.length; i++) if (frame >= starts[i]) seg = i;
  if (seg >= 0) {
    const p = ramp(frame, starts[seg], durs[seg], theme.ease.inOut);
    const a = stops[seg];
    const b = stops[seg + 1];
    const off = seg < 3 ? 78 : 0;
    pos = lerpPt([a[0], a[1] - off], [b[0], b[1] - (seg + 1 < 4 ? 78 : 0)], p);
  }
  const arrived = ramp(frame, tPktFiber + 24, 10);
  const pktO = ramp(frame, tSat[0] + 12, 8) * (1 - arrived);
  const pulse = ramp(frame, tPktFiber + 22, 30);

  const linkP = (k: number) => ramp(frame, tSat[k] - 2, 18);

  return (
    <AbsoluteFill>
      <Stage>
        <Earth cy={CY} R={R} rise={rise} />
        {[1, 2, 3].map((k) => (
          <Beam key={k} a={SATS[k - 1]} b={SATS[k]} p={linkP(k)} strong={frame > starts[k - 1] + hopDur ? 0.45 : 1} width={5} />
        ))}
        <Beam a={SATS[3]} b={GS_TOP} p={ramp(frame, tDown, 18)} strong={0.8} width={5} />
        <Beam a={GS_TOP} b={GLOBE} p={ramp(frame, tFiber, 20)} strong={0.3} width={4} color={theme.colors.textDim} />
        <GroundStation x={GS[0]} y={GS[1] + (1 - gsP) * 40} s={1.15} o={Math.min(1, gsP * 1.5)} glow={0.2} />
        <GlobeIcon x={GLOBE[0]} y={GLOBE[1] - (1 - globeP) * 40} r={62} o={Math.min(1, globeP * 1.5)} glow={pulse * (1 - 0.3 * pulse)} />
        {SATS.map((s, k) => (
          <Satellite key={k} x={s[0]} y={s[1] - (1 - sp[k]) * 100} s={0.8} o={Math.min(1, sp[k] * 1.5)} glow={0.4 + 0.5 * (frame >= tSat[k] + 8 && frame < tSat[k] + 30 ? 1 : 0)} phase={k * 0.9} />
        ))}
        <Packet x={pos[0]} y={pos[1]} o={pktO} />
      </Stage>

      <div style={{ position: "absolute", left: 120, top: 70 }}>
        <WordReveal text="একাধিক *স্যাটেলাইট পেরিয়ে" at={tHead} size={84} align="left" />
      </div>
      <Anchor x={1440} y={1010}>
        <Chip at={tGS + 6} size={30}>Ground Station</Chip>
      </Anchor>
      <Anchor x={1660} y={742}>
        <Chip at={tGlobe + 6} size={30} tone="accent">Internet Network</Chip>
      </Anchor>

      <Sfx name="pop" at={tSat[0] + 2} />
      <Sfx name="pop" at={tGS} rate={0.95} />
      <Sfx name="chime" at={tPktFiber + 22} />
    </AbsoluteFill>
  );
};
