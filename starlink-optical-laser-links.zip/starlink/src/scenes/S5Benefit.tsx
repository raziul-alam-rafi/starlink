import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { ramp, useSpr } from "../components/anim";
import { Anchor, Chip, GlassCard, WordReveal } from "../components/Text";
import {
  Beam,
  CheckMark,
  GlobeIcon,
  GroundStation,
  lerpPt,
  Packet,
  Pt,
  Satellite,
  Stage,
  XMark,
} from "../components/Shapes";
import { Sfx } from "../components/Sfx";
import { SceneProps } from "./util";

// সিন ৫ — Before / After Split (cue ৮-৯)
const L1: Pt = [270, 500];
const L2: Pt = [750, 500];
const LGS_BASE: Pt = [510, 822];
const LGS_TOP: Pt = [510, 730];
const R1: Pt = [1180, 590];
const R2: Pt = [1430, 590];
const RG: Pt = [1690, 590];

export const S5Benefit: React.FC<SceneProps> = ({ t }) => {
  const frame = useCurrentFrame();
  const tHead = t.at(8, 0);
  const tLeft = t.at(8, 0.3);
  const tX = t.at(9, 0);
  const tRight = t.at(9, 0.26);
  const tCheck = t.at(9, 0.76);

  const leftP = useSpr(tLeft + 6, theme.spring.smooth);
  const rightP = useSpr(tRight + 6, theme.spring.smooth);
  const xP = useSpr(tX, theme.spring.bouncy);
  const ckP = useSpr(tCheck, theme.spring.bouncy);
  const dim = 1 - 0.45 * ramp(frame, tX, 16);

  // বাঁ প্যানেল: V-পথে প্যাকেট (নেমে, আবার উঠে)
  const leftLoop = frame < tLeft + 30 ? -1 : ((frame - tLeft - 30) % 90) / 90;
  let lp: Pt = L1;
  if (leftLoop >= 0) {
    lp = leftLoop < 0.5
      ? lerpPt(L1, LGS_TOP, theme.ease.inOut(leftLoop * 2))
      : lerpPt(LGS_TOP, L2, theme.ease.inOut((leftLoop - 0.5) * 2));
  }
  // ডান প্যানেল: সরল পথে প্যাকেট
  const rl = frame < tRight + 30 ? -1 : ((frame - tRight - 30) % 70) / 70;
  let rp: Pt = R1;
  if (rl >= 0) {
    rp = rl < 0.5
      ? lerpPt(R1, R2, theme.ease.inOut(rl * 2))
      : lerpPt(R2, RG, theme.ease.inOut((rl - 0.5) * 2));
  }

  return (
    <AbsoluteFill>
      <Anchor x={960} y={118}>
        <WordReveal text="সবচেয়ে *বড় সুবিধা" at={tHead} size={88} />
      </Anchor>

      <GlassCard at={tLeft} x={110} y={240} w={800} h={650} fade={dim} />
      <GlassCard at={tRight} x={1010} y={240} w={800} h={650} tone="hero" />

      <Stage>
        {/* বাঁ: নেমে আবার পাঠানো */}
        <g opacity={leftP * dim}>
          <path d="M150 858 Q510 786 870 858" fill="none" stroke={theme.colors.line} strokeWidth={3} />
          <Beam a={L1} b={LGS_TOP} p={ramp(frame, tLeft + 10, 20)} strong={0.3} width={4} color={theme.colors.textDim} />
          <Beam a={LGS_TOP} b={L2} p={ramp(frame, tLeft + 22, 20)} strong={0.3} width={4} color={theme.colors.textDim} />
          <GroundStation x={LGS_BASE[0]} y={LGS_BASE[1]} s={0.95} />
          <Satellite x={L1[0]} y={L1[1]} s={0.5} glow={0.2} />
          <Satellite x={L2[0]} y={L2[1]} s={0.5} glow={0.2} phase={1.4} />
          {leftLoop >= 0 ? <Packet x={lp[0]} y={lp[1]} label="" /> : null}
        </g>
        <XMark x={510} y={560} p={xP} r={46} />

        {/* ডান: সরাসরি পথ */}
        <g opacity={rightP}>
          <Beam a={R1} b={R2} p={ramp(frame, tRight + 10, 20)} strong={1} width={6} />
          <Beam a={R2} b={RG} p={ramp(frame, tRight + 22, 20)} strong={1} width={6} />
          <Satellite x={R1[0]} y={R1[1]} s={0.5} glow={0.8} />
          <Satellite x={R2[0]} y={R2[1]} s={0.5} glow={0.8} phase={1.1} />
          <GlobeIcon x={RG[0]} y={RG[1]} r={56} glow={ckP * 0.8} />
          {rl >= 0 ? <Packet x={rp[0]} y={rp[1]} label="" /> : null}
        </g>
        <CheckMark x={1690} y={800} p={ckP} r={38} />
      </Stage>

      <div style={{ position: "absolute", left: 110, top: 292, width: 800, display: "flex", justifyContent: "center", opacity: dim }}>
        <WordReveal text="Ground Station এ নামিয়ে আবার পাঠানো" at={tLeft + 4} size={42} weight={600} maxWidth={700} />
      </div>
      <div style={{ position: "absolute", left: 1010, top: 292, width: 800, display: "flex", justifyContent: "center" }}>
        <WordReveal text="*সরাসরি পথে Data" at={tRight + 4} size={52} />
      </div>
      <Anchor x={1690} y={712}>
        <Chip at={tCheck - 2} size={30} tone="accent">গন্তব্য</Chip>
      </Anchor>
      <Anchor x={1305} y={720}>
        <Chip at={tRight + 24} size={28}>Optical Laser</Chip>
      </Anchor>

      <Sfx name="pop" at={tLeft + 4} />
      <Sfx name="click" at={tX + 2} />
      <Sfx name="pop" at={tRight + 4} rate={1.06} />
      <Sfx name="click" at={tCheck + 2} rate={1.08} />
    </AbsoluteFill>
  );
};
