import React from "react";
import { S1Hook } from "./S1Hook";
import { S2Problem } from "./S2Problem";
import { S3Relay } from "./S3Relay";
import { S4Network } from "./S4Network";
import { S5Benefit } from "./S5Benefit";
import { S6End } from "./S6End";
import type { SceneProps } from "./util";

// SCENE_CUES (timing.ts) এর একই ক্রমে
export const SCENES: React.FC<SceneProps>[] = [S1Hook, S2Problem, S3Relay, S4Network, S5Benefit, S6End];
