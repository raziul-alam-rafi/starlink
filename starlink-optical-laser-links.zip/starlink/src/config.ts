// ভয়েসওভার ফ্ল্যাগ: public/voiceover.mp3 থাকলে তবেই বাজবে, না থাকলে নীরবে বাদ।
export const VOICEOVER_IN_PREVIEW = true; // Remotion Studio প্রিভিউতে চালু
export const VOICEOVER_IN_RENDER = false; // MP4 রেন্ডারে ডিফল্টে বন্ধ
export const VOICEOVER_FILE = "voiceover.mp3";
