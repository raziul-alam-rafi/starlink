import { loadFont } from "@remotion/google-fonts/HindSiliguri";

// Hind Siliguri: যুক্তাক্ষর ঠিক আসে; বাংলা ও ল্যাটিন দুটোই একই ফ্যামিলিতে।
const { fontFamily } = loadFont("normal", {
  weights: ["400", "500", "600", "700"],
  subsets: ["bengali", "latin"],
});

export const FONT_STACK = `"${fontFamily}", "Noto Sans Bengali", sans-serif`;
