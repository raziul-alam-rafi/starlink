// SFX যাচাই: দৈর্ঘ্য, peak, RMS, clipping
import fs from "node:fs";
import path from "node:path";

const dir = path.resolve("public/sfx");
const rows = [];
let bad = 0;
for (const f of fs.readdirSync(dir).filter((n) => n.endsWith(".wav")).sort()) {
  const b = fs.readFileSync(path.join(dir, f));
  const sr = b.readUInt32LE(24);
  const n = (b.length - 44) / 2;
  let peak = 0, sum = 0, clip = 0;
  for (let i = 0; i < n; i++) {
    const s = b.readInt16LE(44 + i * 2);
    peak = Math.max(peak, Math.abs(s));
    sum += s * s;
    if (Math.abs(s) >= 32700) clip++;
  }
  const dur = n / sr;
  const rms = Math.sqrt(sum / n);
  const db = (v) => (20 * Math.log10(v / 32768)).toFixed(1);
  const limit = f.startsWith("whoosh") || f.startsWith("swipe") ? 0.8 : 0.5;
  const ok = dur <= limit && clip === 0;
  if (!ok) bad++;
  rows.push(`${f.padEnd(12)} dur=${dur.toFixed(3)}s  peak=${db(peak)} dBFS  rms=${db(rms)} dBFS  clipped=${clip}  ${ok ? "OK" : "FAIL"}`);
}
console.log(rows.join("\n"));
process.exit(bad ? 1 : 0);
