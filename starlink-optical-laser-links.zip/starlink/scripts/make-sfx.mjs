// SFX সিন্থেসাইজার — ডাউনলোড ছাড়া, নির্ধারিত (deterministic)।
// আউটপুট: public/sfx/{pop,click,whoosh,swipe,chime,thud}.wav (মনো, 16-bit, 44.1kHz)
import fs from "node:fs";
import path from "node:path";

const SR = 44100;
const OUT = path.resolve("public/sfx");
fs.mkdirSync(OUT, { recursive: true });

let seed = 20261020;
const rnd = () => {
  seed = (seed * 1664525 + 1013904223) >>> 0;
  return seed / 4294967296 - 0.5;
};

class Biquad {
  constructor() { this.z1 = 0; this.z2 = 0; this.c = [1, 0, 0, 0, 0]; }
  set(type, f, Q = 0.707) {
    const w0 = (2 * Math.PI * Math.min(f, SR * 0.45)) / SR;
    const cos = Math.cos(w0);
    const alpha = Math.sin(w0) / (2 * Q);
    let b0, b1, b2;
    if (type === "lp") { b0 = (1 - cos) / 2; b1 = 1 - cos; b2 = (1 - cos) / 2; }
    else if (type === "hp") { b0 = (1 + cos) / 2; b1 = -(1 + cos); b2 = (1 + cos) / 2; }
    else { b0 = alpha; b1 = 0; b2 = -alpha; } // bp
    const a0 = 1 + alpha;
    this.c = [b0 / a0, b1 / a0, b2 / a0, (-2 * cos) / a0, (1 - alpha) / a0];
  }
  tick(x) {
    const [b0, b1, b2, a1, a2] = this.c;
    const y = b0 * x + this.z1;
    this.z1 = b1 * x - a1 * y + this.z2;
    this.z2 = b2 * x - a2 * y;
    return y;
  }
}

const lowpass = (x, f) => {
  const b = new Biquad();
  b.set("lp", f, 0.707);
  return x.map((v) => b.tick(v));
};

// খুব ছোট reverb (Schroeder comb ×3), হালকা মিক্স
const reverb = (x, mixAmt = 0.1) => {
  const delays = [1327, 1637, 1867];
  const y = new Float64Array(x.length);
  const bufs = delays.map((d) => new Float64Array(d));
  const idx = delays.map(() => 0);
  for (let n = 0; n < x.length; n++) {
    let wet = 0;
    for (let k = 0; k < delays.length; k++) {
      const o = bufs[k][idx[k]];
      bufs[k][idx[k]] = x[n] + o * 0.3;
      idx[k] = (idx[k] + 1) % delays[k];
      wet += o;
    }
    y[n] = x[n] + (wet / delays.length) * mixAmt * 3;
  }
  return y;
};

const finish = (x, fadeMs = 14, inMs = 1.5) => {
  const fi = Math.round((inMs / 1000) * SR);
  const fo = Math.round((fadeMs / 1000) * SR);
  for (let i = 0; i < fi; i++) x[i] *= i / fi;
  for (let i = 0; i < fo; i++) x[x.length - 1 - i] *= i / fo;
  return x;
};

const make = (sec, fn) => {
  const n = Math.round(sec * SR);
  const x = new Float64Array(n);
  for (let i = 0; i < n; i++) x[i] = fn(i / SR, i / n);
  return x;
};

const sounds = {};

// pop: দ্রুত নিচে নামা pitch-এর sine + ছোট envelope
sounds.pop = (() => {
  let ph = 0;
  const x = make(0.22, (t) => {
    const f = 180 + 420 * Math.exp(-t / 0.035);
    ph += (2 * Math.PI * f) / SR;
    const env = (1 - Math.exp(-t / 0.004)) * Math.exp(-t / 0.055);
    return (Math.sin(ph) + 0.16 * Math.sin(2 * ph)) * env;
  });
  return finish(reverb(lowpass(x, 3200), 0.08));
})();

// click: high-pass করা ছোট noise burst + অতি ছোট টিক
sounds.click = (() => {
  const hp = new Biquad();
  hp.set("hp", 2200, 0.7);
  const x = make(0.12, (t) => {
    const env = (1 - Math.exp(-t / 0.0008)) * Math.exp(-t / 0.008);
    const n = hp.tick(rnd() * 2) * env;
    const tick = Math.sin(2 * Math.PI * 1900 * t) * Math.exp(-t / 0.006) * 0.3;
    return n + tick;
  });
  return finish(reverb(lowpass(x, 7500), 0.06), 10);
})();

// whoosh: band-pass noise sweep (নিচের দিকে), fade in/out
sounds.whoosh = (() => {
  const bp = new Biquad();
  const dur = 0.5;
  const x = make(dur, (t, u) => {
    if (Math.round(t * SR) % 32 === 0) bp.set("bp", 1900 * Math.pow(420 / 1900, Math.pow(u, 0.8)), 1.1);
    const env = u < 0.3 ? Math.pow(u / 0.3, 1.5) : Math.exp(-(u - 0.3) * 5.2);
    return bp.tick(rnd() * 2) * env;
  });
  return finish(reverb(lowpass(x, 4500), 0.08), 30, 4);
})();

// swipe: ট্রানজিশন — ওপরের দিকে band-pass sweep, গাউসিয়ান envelope
sounds.swipe = (() => {
  const bp = new Biquad();
  const dur = 0.7;
  const x = make(dur, (t, u) => {
    if (Math.round(t * SR) % 32 === 0) bp.set("bp", 300 * Math.pow(2600 / 300, u), 0.9);
    const env = Math.exp(-Math.pow((u - 0.5) / 0.22, 2));
    return bp.tick(rnd() * 2) * env;
  });
  return finish(reverb(lowpass(x, 5000), 0.08), 30, 6);
})();

// chime: নরম ওভারটোনসহ ছোট decay
sounds.chime = (() => {
  const parts = [
    [1318.5, 1.0, 0.17],
    [2637, 0.32, 0.1],
    [3640, 0.14, 0.055],
  ];
  const x = make(0.5, (t) => {
    const att = 1 - Math.exp(-t / 0.003);
    let s = 0;
    for (const [f, a, d] of parts) s += Math.sin(2 * Math.PI * f * t) * a * Math.exp(-t / d);
    return s * att;
  });
  return finish(reverb(lowpass(x, 6000), 0.1), 60);
})();

// thud: খুব হালকা সফট থাড (হুকের জন্য)
sounds.thud = (() => {
  let ph = 0;
  const x = make(0.32, (t) => {
    const f = 48 + 40 * Math.exp(-t / 0.05);
    ph += (2 * Math.PI * f) / SR;
    return Math.sin(ph) * (1 - Math.exp(-t / 0.008)) * Math.exp(-t / 0.09);
  });
  return finish(lowpass(x, 220), 40);
})();

// লেভেল মেলানো: RMS লক্ষ্য, কিন্তু peak ≤ 0.89 (clipping নেই)
const TARGET_RMS = 0.1;
const PEAK_MAX = 0.89;
const writeWav = (name, x) => {
  let peak = 0, sum = 0;
  for (const v of x) { peak = Math.max(peak, Math.abs(v)); sum += v * v; }
  const rms = Math.sqrt(sum / x.length);
  const g = Math.min(PEAK_MAX / peak, TARGET_RMS / rms);
  const buf = Buffer.alloc(44 + x.length * 2);
  buf.write("RIFF", 0); buf.writeUInt32LE(36 + x.length * 2, 4); buf.write("WAVEfmt ", 8);
  buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(SR, 24); buf.writeUInt32LE(SR * 2, 28); buf.writeUInt16LE(2, 32);
  buf.writeUInt16LE(16, 34); buf.write("data", 36); buf.writeUInt32LE(x.length * 2, 40);
  for (let i = 0; i < x.length; i++) {
    const s = Math.max(-1, Math.min(1, x[i] * g));
    buf.writeInt16LE(Math.round(s * 32767), 44 + i * 2);
  }
  fs.writeFileSync(path.join(OUT, `${name}.wav`), buf);
};

for (const [name, x] of Object.entries(sounds)) writeWav(name, x);
console.log("SFX written to", OUT);
